# @mennara/http

The HTTP client every Mennara browser app uses to talk to its own backend (BFF).

## What belongs here

- `createHttpClient`: base URL, credentials (`include` by default), timeouts, JSON and `FormData` bodies, query strings
- CSRF headers: on unsafe methods by default, or on every request (`methods: "all"`)
- `HttpError` and parsing of the platform error envelope `{ error: { code, message, details } }` (FastAPI `detail` also accepted)
- `onRequest`, `onResponse`, `onError` hooks for app rules such as session checks and login redirects
- URL config helpers: `requireEnv`, `normalizeHttpUrl`, `normalizeHttpOrigin`

## What does not belong here

- Login, sessions, account switching or permissions (`@mennara/auth`)
- Business endpoints and types (`@mennara/api`)
- React, Next.js, or reading `process.env`
- Automatic retries: replaying a mutation can apply it twice, so callers decide

## Usage

```ts
import { createHttpClient, getErrorMessage } from "@mennara/http"

export const http = createHttpClient({
  baseUrl: "/api/console",
  csrf: { header: "X-CSRF-Token", getToken: () => csrfStore.get(), methods: "all" },
  onError: (_context, error) => {
    if (error.status === 401) redirectToLogin()
  },
})

const users = await http.get<User[]>("/users", { query: { q: "ravi" } })
await http.post("/users", { name: "Ravi" })
await http.get("/invitations/token-preview", { csrf: false })
```

Requests resolve with the parsed body; empty responses resolve with `undefined`. Failures reject with `HttpError` (`status`, `code`, `details`, `body`). Network failures and timeouts have `status: 0` and code `network_error` or `request_timeout`. A request cancelled through `signal` rejects with the abort error unchanged.

`context.meta` is a per-request object shared by the hooks of one request, for example to remember a session version in `onRequest` and compare it in `onResponse`.
